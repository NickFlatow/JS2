// Recipe Model
var Recipe = function(){
    return {
        name: '',
        image: null,
        description: '',
        ingredients: [''],
        directions: [''],
        rating: 0,
    }
};


// Initialize Firebase
// TODO: Insert firebase config/init here


// Create references to firestore and storage
// TODO
