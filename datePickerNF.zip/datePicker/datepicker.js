$(document).ready(function() {
    $("#dp").datepicker({
        showOtherMonths: true,
        selectOtherMonths:true,
        showButtonPanel:true,
        showAnim:'clip',
        onSelect: function(dateText) {
            alert(dateText);
        }
    });
    $("#datePickerLink").click(function() {
        $("#dp").datepicker("show");
    });
});